/**
 * E2E v37 — Assistant pédagogique IA conversationnel.
 *
 * ⚠️ SUSPENDU EN v38 : à la demande de l'utilisateur, l'Assistant Master
 * Soutien Pédagogique IA et le Générateur de fiches APC avec IA sont passés
 * en « À venir » le temps d'être perfectionnés. Leurs routes affichent donc
 * l'écran d'attente et ce scénario ne peut plus s'exécuter.
 *
 * Le code applicatif (aiInterview.ts, lessonEnrichment.ts,
 * AIAssistantChatScreen.tsx) est CONSERVÉ intact, et le scénario de test est
 * archivé dans tests/e2e-v37.suspendu.txt. Pour tout réactiver :
 *   1. passer comingSoon: false dans src/utils/appModules.ts ;
 *   2. rétablir les deux routes dans src/App.tsx ;
 *   3. restaurer ce fichier depuis l'archive.
 *
 * La couverture de ces modules reste assurée par la section 46 de l'audit.
 */
console.log('\n=== E2E v37 — SUSPENDU (fonctionnalité passée en « À venir » en v38) ===');
console.log('    Scénario archivé dans tests/e2e-v37.suspendu.txt\n');
process.exit(0);
