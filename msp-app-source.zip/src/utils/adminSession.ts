/**
 * SESSION ADMINISTRATEUR (v38) — lecture partagée.
 *
 * Permet aux écrans hors tableau de bord (bibliothèque, boutique de cours)
 * de savoir si un Super Administrateur est connecté, sans dupliquer la
 * logique d'authentification.
 */

export const ADMIN_SESSION_KEY = 'msp_admin_dashboard_session';
export const ADMIN_TEAM_KEY = 'msp_admin_team';

/** Identifiant de session courant ('owner', 'member:xxx') ou null. */
export function getAdminSession(): string | null {
  try {
    return localStorage.getItem(ADMIN_SESSION_KEY);
  } catch {
    return null;
  }
}

/**
 * Un Super Administrateur est-il connecté ?
 * 'owner' = administrateur principal (code général de l'application).
 */
export function isSuperAdminSession(): boolean {
  const session = getAdminSession();
  if (!session) return false;
  if (session === 'owner') return true;
  if (!session.startsWith('member:')) return false;
  const id = session.slice('member:'.length);
  try {
    const raw = localStorage.getItem(ADMIN_TEAM_KEY);
    const team = raw ? JSON.parse(raw) : [];
    if (!Array.isArray(team)) return false;
    const member = team.find((m: any) => m && m.id === id);
    return !!member && member.active !== false && member.role === 'Super Administrateur';
  } catch {
    return false;
  }
}

/** Un administrateur (quel que soit son rôle) est-il connecté ? */
export function isAnyAdminSession(): boolean {
  return !!getAdminSession();
}
