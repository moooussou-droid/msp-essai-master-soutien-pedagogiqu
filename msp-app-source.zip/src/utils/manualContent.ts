/**
 * LE MANUEL DE L'ABONNÉ (v58) — contenu intégré à l'application.
 *
 * Reprend le manuel d'utilisation, pour qu'il soit consultable DANS
 * l'application, hors connexion, et exportable en PDF.
 *
 * Le contenu vit ici, séparé de l'écran : la présentation peut changer
 * sans toucher au texte, et le texte peut être corrigé sans risquer de
 * casser l'affichage.
 */

import { normalizeSearch } from './textSearch';

export interface ManualStep {
  titre: string;
  /** Chemin de navigation réel, depuis l'accueil. */
  chemin: string;
  role: string;
  etapes: string[];
  /** Documents produits : PDF, Word, Excel, impression. */
  sorties?: string;
  astuce?: string;
  attention?: string;
}

export interface ManualChapter {
  id: string;
  titre: string;
  /** Résumé affiché sous le titre, avant ouverture. */
  resume: string;
  fiches: ManualStep[];
}

export const MANUAL_INTRO = [
  {
    titre: 'Trois principes à connaître',
    texte:
      '① Tout fonctionne sans internet. L’application est conçue pour la classe, '
      + 'y compris là où le réseau est absent.\n\n'
      + '② Vos données restent sur votre appareil. C’est un avantage pour la '
      + 'confidentialité, mais si vous perdez le téléphone sans sauvegarde, vous '
      + 'perdez l’année. Sauvegardez chaque semaine.\n\n'
      + '③ L’impression accompagne toujours le PDF. Chaque document peut être '
      + 'enregistré, exporté et imprimé.',
  },
  {
    titre: 'Le bouton Retour',
    texte:
      'En haut à gauche de chaque écran, le bouton Retour vous ramène à la page '
      + 'précédente — jamais brutalement à l’accueil. Explorez sans crainte.',
  },
];

export const MANUAL: ManualChapter[] = [
  {
    id: 'ch1',
    titre: '1. Premiers pas',
    resume: 'Activer, se présenter, créer sa première classe.',
    fiches: [
      {
        titre: 'Mon profil',
        chemin: 'Accueil → icône Profil',
        role: 'Renseigner votre identité et celle de l’école : ces informations figurent sur tous vos documents.',
        etapes: [
          'Saisissez votre nom, celui de l’école, la circonscription et la commune.',
          'Ajoutez le logo de l’école si vous le souhaitez.',
          'Enregistrez : bulletins, PV, reçus et courriers reprendront ces mentions.',
        ],
        astuce: 'Remplissez ce profil avant votre premier document, pour ne pas avoir à tout réimprimer.',
      },
      {
        titre: 'Créer une classe',
        chemin: 'Accueil → « + Classe »',
        role: 'Créer l’espace de travail d’une classe : c’est le point de départ de tout le reste.',
        etapes: [
          'Touchez « + Classe ».',
          'Renseignez le nom, le type d’enseignement, le niveau, l’école et la circonscription.',
          'Validez : le tableau de bord de la classe s’ouvre.',
        ],
        attention: 'Le type d’enseignement détermine le calcul des bulletins. Le modifier ensuite change tous vos calculs.',
      },
    ],
  },
  {
    id: 'ch2',
    titre: '2. La classe au quotidien',
    resume: 'Élèves, matières, saisie des notes et présences.',
    fiches: [
      {
        titre: 'Élèves',
        chemin: 'Classe → Gestion → Élèves',
        role: 'Inscrire, modifier et trier les élèves.',
        etapes: [
          'Ajoutez les élèves un par un : nom, prénoms, matricule, sexe.',
          'Ou importez la liste officielle depuis un fichier Excel.',
          'Utilisez la recherche et le tri pour naviguer dans la liste.',
        ],
        sorties: 'Excel · PDF · Impression',
        attention: 'Le matricule garde ses zéros initiaux (001 reste 001). Un matricule erroné fait rejeter la ligne par EducMaster.',
      },
      {
        titre: 'Matières',
        chemin: 'Classe → Gestion → Matières',
        role: 'Définir les matières, leurs barèmes et leurs coefficients.',
        etapes: [
          'Vérifiez la liste proposée selon le niveau.',
          'Réglez la note obtenue maximale (CM) et la note de perfectionnement (CP).',
          'Dans le secondaire, renseignez les coefficients.',
        ],
        astuce: 'Réglez les barèmes AVANT de saisir : les modifier ensuite oblige à revoir toutes les notes.',
      },
      {
        titre: 'Saisir les notes',
        chemin: 'Classe → Suivi pédagogique → Saisir les notes',
        role: 'Enregistrer les notes, évaluation par évaluation.',
        etapes: [
          'Choisissez l’évaluation en haut de l’écran.',
          'Choisissez le mode : « Par matière » ou « Par profil ».',
          'Saisissez la note obtenue (CM) et la note de perfectionnement (CP).',
          'Si l’élève n’a pas composé, cochez « Absent ».',
        ],
        attention: 'Absent n’est pas zéro. Un zéro est une note qui pèse sur la moyenne ; une absence est traitée autrement.',
        astuce: 'Chaque évaluation garde ses propres notes : la sommative 2 n’efface pas la sommative 1.',
      },
      {
        titre: 'Présences',
        chemin: 'Classe → Suivi pédagogique → Présences des élèves',
        role: 'Faire l’appel du matin et de l’après-midi.',
        etapes: [
          'Choisissez la date puis la demi-journée.',
          'Indiquez : présent, absence justifiée, absence injustifiée ou férié.',
          'Précisez le motif pour une absence justifiée.',
        ],
        sorties: 'PDF · Excel · Impression',
        astuce: 'Le mercredi ne compte qu’une demi-journée, et il n’y a ni samedi ni dimanche.',
      },
    ],
  },
  {
    id: 'ch3',
    titre: '3. Les documents de l’élève',
    resume: 'Bulletins, tableau PV, statistiques et fichier EducMaster.',
    fiches: [
      {
        titre: 'Bulletins & classement',
        chemin: 'Classe → Suivi pédagogique → Bulletins & classement',
        role: 'Produire les bulletins officiels avec moyenne, rang et mention.',
        etapes: [
          'Choisissez l’évaluation : chaque évaluation a son propre bulletin.',
          'Vérifiez la moyenne de classe et le taux de réussite.',
          'Exportez : Excel récapitulatif, Word, PDF des bulletins ou PDF récapitulatif.',
        ],
        sorties: 'Excel · Word · PDF · Impression',
      },
      {
        titre: 'Tableau des notes (PV)',
        chemin: 'Classe → Suivi pédagogique → Tableau des notes',
        role: 'Voir toute la classe d’un seul coup d’œil.',
        etapes: [
          'Choisissez l’évaluation.',
          'Consultez notes, moyennes, matières validées et seuil atteint.',
          'Téléchargez le PDF ou imprimez.',
        ],
        sorties: 'PDF · Impression',
        astuce: 'L’écran le plus rapide pour repérer une note manquante avant un export.',
      },
      {
        titre: 'Export EducMaster',
        chemin: 'Classe → Gestion → Export EducMaster',
        role: 'Produire le fichier Excel officiel à importer sur educmaster.bj.',
        etapes: [
          'Vérifiez la barre « Progression de la saisie » : elle doit être verte.',
          'Touchez « Télécharger le fichier Excel ».',
          'Importez le fichier sur educmaster.bj.',
        ],
        sorties: 'Excel (format EducMaster)',
        attention: 'N’ouvrez pas le fichier dans Excel avant l’import : les matricules perdraient leurs zéros initiaux.',
        astuce: 'Barre orange = notes manquantes. N’exportez pas dans ce cas.',
      },
    ],
  },
  {
    id: 'ch4',
    titre: '4. Mes registres officiels',
    resume: 'Cahier journal et registre matricule — ce que réclame l’inspection.',
    fiches: [
      {
        titre: 'Cahier journal',
        chemin: 'Accueil → Registres → Cahier journal',
        role: 'Consigner chaque jour les séances réellement faites.',
        etapes: [
          'Choisissez la date et la classe.',
          'Pour chaque séance : matière, titre, durée, déroulement.',
          'Marquez « Faite » ou « À faire », avec le motif du report.',
        ],
        sorties: 'Word · PDF · Impression',
        astuce: 'Le taux de réalisation est calculé : c’est l’indicateur que regarde l’inspecteur.',
      },
      {
        titre: 'Registre matricule',
        chemin: 'Accueil → Registres → Registre matricule',
        role: 'Tenir le registre officiel des inscriptions.',
        etapes: [
          'Touchez « Inscrire un élève ».',
          'Renseignez identité, admission, provenance et contact.',
          'Au départ d’un élève : date et motif de sortie.',
        ],
        sorties: 'Word · PDF · Impression',
        attention: 'Un élève sorti n’est jamais effacé : il reste au registre avec sa date de sortie.',
      },
    ],
  },
  {
    id: 'ch5',
    titre: '5. Ma vie scolaire',
    resume: 'Appel officiel, paiements, livret, matériel, emploi du temps, conseil.',
    fiches: [
      {
        titre: 'Registre d’appel officiel',
        chemin: 'Accueil → Vie scolaire → Registre d’appel officiel',
        role: 'Produire le taux de fréquentation réglementaire.',
        etapes: [
          'Choisissez la classe et le mois.',
          'Consultez le taux, sa ventilation garçons / filles et le détail par élève.',
          'Exportez en Word ou PDF, ou imprimez.',
        ],
        sorties: 'Word · PDF · Impression',
        astuce: 'Calcul en demi-journées ; les jours fériés sont exclus du total.',
      },
      {
        titre: 'Paiements des élèves',
        chemin: 'Accueil → Vie scolaire → Paiements des élèves',
        role: 'Suivre qui a payé, combien, et ce qui reste dû.',
        etapes: [
          'Choisissez la classe et le type de frais à appeler.',
          'Indiquez le montant appelé : une ligne est créée par élève.',
          'Touchez « Encaisser » : le reçu numéroté est généré en PDF.',
        ],
        sorties: 'Reçu PDF · Situation PDF · Impression',
        attention: 'Un trop-perçu n’est jamais masqué : il s’affiche en négatif et doit être régularisé.',
      },
      {
        titre: 'Livret scolaire',
        chemin: 'Accueil → Vie scolaire → Livret scolaire',
        role: 'Retracer le parcours d’un élève d’une année sur l’autre, du CI au CM2.',
        etapes: [
          'Touchez « Créer les livrets depuis mes classes ».',
          'Ouvrez le livret d’un élève.',
          'Ajoutez une année : depuis une classe existante, ou manuellement.',
          'Consultez la moyenne générale et la tendance calculées.',
        ],
        sorties: 'Word · PDF · Impression',
        astuce: 'Document précieux pour l’orientation et les dossiers de transfert.',
      },
      {
        titre: 'Manuels et matériel',
        chemin: 'Accueil → Vie scolaire → Manuels et matériel',
        role: 'Savoir qui détient quel manuel, et ce qui est prêté, perdu ou à racheter.',
        etapes: [
          'Ajoutez un article : nom, catégorie, quantité et valeur unitaire.',
          'Touchez « Prêter » et choisissez l’élève.',
          'Au retour, marquez « Rendu », « Perdu » ou « Abîmé ».',
        ],
        sorties: 'Word (paysage) · PDF · Impression',
        attention: 'Si le disponible devient négatif, l’application le signale : plus d’exemplaires ont été prêtés que l’école n’en possède. L’anomalie n’est jamais masquée.',
      },
      {
        titre: 'Emploi du temps',
        chemin: 'Accueil → Vie scolaire → Emploi du temps',
        role: 'Construire la grille hebdomadaire de la classe, affichable et imprimable.',
        etapes: [
          'Choisissez la classe.',
          'Pour chaque jour, ajoutez un créneau : début, fin et matière.',
          'Vérifiez le volume horaire calculé par matière.',
          'Enregistrez, puis exportez ou imprimez pour l’afficher en classe.',
        ],
        sorties: 'Word (paysage) · PDF · Impression',
        astuce: 'L’application détecte les chevauchements : deux matières au même créneau déclenchent une alerte rouge.',
      },
      {
        titre: 'Élèves en difficulté (remédiation)',
        chemin: 'Accueil → Vie scolaire → Élèves en difficulté',
        role: 'Garder la trace des actions engagées et de leurs résultats.',
        etapes: [
          'Choisissez la classe : les élèves sous 10/20 sans dossier sont proposés automatiquement.',
          'Touchez un élève proposé pour ouvrir son dossier.',
          'Renseignez la matière et la difficulté constatée.',
          'Ajoutez les actions menées, avec leur date et le résultat observé.',
          'Mettez à jour la note actuelle et le statut du dossier.',
        ],
        sorties: 'Word (paysage) · PDF · Impression',
        astuce: 'Le taux de résolution et le gain moyen en points sont calculés : exactement ce que demande l’inspection.',
      },
      {
        titre: 'Sauvegarde et restauration',
        chemin: 'Accueil → Vie scolaire → Sauvegarde',
        role: 'Protéger toute votre année dans un fichier unique.',
        etapes: [
          'Touchez « Télécharger la sauvegarde ».',
          'Conservez le fichier sur un second appareil ou une clé USB.',
          'Pour restaurer : « Choisir un fichier de sauvegarde ».',
        ],
        sorties: 'Fichier de sauvegarde (.json)',
        attention: 'La restauration REMPLACE les données de l’appareil. Sauvegardez avant, en cas de doute.',
        astuce: 'C’est le module le plus important : il protège tous les autres.',
      },
      {
        titre: 'Conseil de classe',
        chemin: 'Accueil → Vie scolaire → Conseil de classe',
        role: 'Conduire la délibération et produire le procès-verbal.',
        etapes: [
          'Choisissez la classe, touchez « Préparer la délibération ».',
          'Moyennes, mentions et décisions sont pré-remplies.',
          'Modifiez les décisions au besoin, puis exportez le PV.',
        ],
        sorties: 'Word · PDF · Impression',
        attention: 'L’application PROPOSE, le conseil DÉCIDE. Les décisions restent modifiables.',
      },
    ],
  },
  {
    id: 'ch6',
    titre: '6. La cantine scolaire',
    resume: 'Effectifs, simulateur, menus et stocks des vivres.',
    fiches: [
      {
        titre: 'Relevé des effectifs par classe',
        chemin: 'Accueil → Cantine → Relevé des effectifs',
        role: 'Compter les élèves à nourrir, de la maternelle au CM2.',
        etapes: [
          'Vérifiez la date du relevé en haut de l’écran.',
          'Renseignez les garçons et les filles de chaque classe.',
          'Enregistrez : les totaux et la parité sont calculés.',
        ],
        sorties: 'PDF · Excel · Impression',
        astuce: 'Changer la date crée un NOUVEAU relevé : les relevés précédents sont conservés et consultables dans l’historique.',
      },
      {
        titre: 'Super MSP Simulateur cantine',
        chemin: 'Accueil → Cantine → Super MSP Simulateur cantine',
        role: 'Calculer les quantités de vivres à sortir chaque semaine.',
        etapes: [
          'Renseignez les effectifs et la période.',
          'Choisissez la légumineuse, ou « Aucune ».',
          'Les quantités et reliquats sont calculés automatiquement.',
        ],
        sorties: 'PDF · Excel · Impression',
        attention: 'Vous ne saisissez jamais une quantité calculée. Un reliquat négatif est signalé, jamais masqué.',
      },
      {
        titre: 'Cahiers MSP des menus et des stocks',
        chemin: 'Accueil → Cantine → Cahiers MSP',
        role: 'Tenir le cahier officiel des menus et suivre chaque denrée.',
        etapes: [
          'Cahier des menus : renseignez le menu de chaque jour.',
          'Rations, effectifs et quantités à sortir sont repris automatiquement.',
          'Cahier des stocks : une section par denrée, dotations et sorties.',
        ],
        sorties: 'PDF · Excel · Impression',
        astuce: 'Les unités sont paramétrables selon vos habitudes.',
      },
    ],
  },
  {
    id: 'ch7',
    titre: '7. La gestion financière',
    resume: 'Recettes, dépenses, budget et bilan OHADA.',
    fiches: [
      {
        titre: 'Recettes et dépenses du jour',
        chemin: 'Accueil → Comptabilité → Recettes et dépenses du jour',
        role: 'Tenir le journal quotidien des mouvements d’argent de l’école.',
        etapes: [
          'Enregistrez les recettes du jour, par classe et par volet.',
          'Enregistrez les dépenses du jour, avec leur objet.',
          'Consultez le solde de la journée.',
        ],
        sorties: 'PDF · Excel · Impression',
      },
      {
        titre: 'Le budget de mon école',
        chemin: 'Accueil → Comptabilité → Le budget de mon école',
        role: 'Établir le budget, le bilan et l’inventaire de l’établissement.',
        etapes: [
          'Renseignez les postes de recettes et de dépenses prévus.',
          'Comparez le réalisé au prévu.',
          'Produisez le bilan et l’inventaire au format OHADA.',
        ],
        sorties: 'PDF · Excel · Impression',
      },
    ],
  },
  {
    id: 'ch8',
    titre: '8. Préparation de classe',
    resume: 'Planification, fiches pédagogiques et programmes.',
    fiches: [
      {
        titre: 'Planification annuelle',
        chemin: 'Accueil → Préparation de classe → Planification annuelle',
        role: 'Répartir les apprentissages sur l’année scolaire.',
        etapes: [
          'Choisissez la classe.',
          'Renseignez les apprentissages prévus par période.',
          'Enregistrez, puis exportez pour l’inspection.',
        ],
        sorties: 'PDF · Impression',
      },
      {
        titre: 'Fiches pédagogiques',
        chemin: 'Accueil → Préparation de classe → Fiches pédagogiques',
        role: 'Rédiger et conserver vos fiches de préparation de séance.',
        etapes: [
          'Créez une fiche : matière, compétence visée, déroulement, matériel.',
          'Enregistrez : la fiche reste modifiable.',
          'Exportez en PDF ou imprimez pour le classeur de préparation.',
        ],
        sorties: 'PDF · Impression',
      },
      {
        titre: 'Programme d’études',
        chemin: 'Classe → Documents & outils → Programme d’études',
        role: 'Consulter les documents officiels du programme.',
        etapes: [
          'Choisissez le niveau et la matière.',
          'Appuyez-vous dessus pour vos préparations.',
        ],
        sorties: 'PDF · Impression',
        attention: 'L’Assistant MSP IA et le Générateur de fiches APC sont annoncés « À venir » : ils ne sont pas encore disponibles.',
      },
    ],
  },
  {
    id: 'ch9',
    titre: '9. Ressources et savoirs',
    resume: 'Encyclopédie, dictionnaire, cours et images éducatives.',
    fiches: [
      {
        titre: 'Encyclopédie MSP et Dictionnaire MSP',
        chemin: 'Accueil → Savoirs & cours',
        role: 'Consulter les contenus de référence utilisables en classe.',
        etapes: [
          'Encyclopédie : 9 domaines et 24 thématiques, avec images et vidéos.',
          'Dictionnaire : les mots expliqués simplement aux jeunes élèves.',
          'Recherchez un mot ou parcourez les thèmes.',
        ],
        sorties: 'Consultation · Impression',
      },
      {
        titre: 'Bibliothèque et Cours',
        chemin: 'Accueil → Savoirs & cours',
        role: 'Accéder aux ouvrages PDF et aux cours de l’application.',
        etapes: [
          'Bibliothèque : parcourez le catalogue des ouvrages.',
          'Cours : choisissez le niveau et la matière.',
          'Toute modification apportée à une leçon est conservée.',
        ],
        sorties: 'PDF · Impression',
        astuce: 'Les contenus payants se débloquent après paiement au Super Administrateur.',
      },
      {
        titre: 'Éducation à la vie',
        chemin: 'Accueil → Éducation à la vie',
        role: 'Trois séries de 50 cours prêts à utiliser en classe.',
        etapes: [
          'Environnement : eau, déchets, sols, forêts, climat.',
          'Argent : épargne, budget, tontines, crédit, arnaques.',
          'Entreprise : trouver une idée, calculer un prix, tenir ses comptes.',
        ],
        sorties: 'PDF · Impression',
      },
      {
        titre: 'Mes images éducatives',
        chemin: 'Accueil → Mes images éducatives',
        role: 'Obtenir des illustrations et signer vos documents.',
        etapes: [
          'Générateur local : créez une gravure sans internet.',
          'Banque d’images : 12 images de contexte béninois, 100 F l’unité.',
          'Signature : personnalisez la mention apposée sur vos productions (500 F).',
        ],
        sorties: 'Images · PDF',
        astuce: 'Par défaut, vos documents portent la signature « Master Soutien Pédagogique (Votre compagnon mobile) ».',
      },
    ],
  },
  {
    id: 'ch10',
    titre: '10. Outils du quotidien',
    resume: 'Chronomètre, calculatrice, numériseur et organisation.',
    fiches: [
      {
        titre: 'Chronomètre de performances',
        chemin: 'Accueil → Mes outils → Chronomètre',
        role: 'Chronométrer les performances sportives des élèves.',
        etapes: [
          'Touchez « Démarrer ».',
          'À chaque arrivée, touchez « Top arrivée ».',
          'Enregistrez la session, puis exportez ou imprimez.',
        ],
        sorties: 'PDF · Impression',
      },
      {
        titre: 'Numériser un document',
        chemin: 'Accueil → Mes outils → Numériser un document',
        role: 'Transformer une feuille en document numérique de qualité.',
        etapes: [
          'Prenez une photo, ou importez un fichier existant.',
          'Traitement haute définition en noir et blanc.',
          'Ajoutez d’autres pages, puis enregistrez en PDF ou imprimez.',
        ],
        sorties: 'PDF · Impression',
      },
      {
        titre: 'Calculatrice, horloge et boîte à outils',
        chemin: 'Accueil → Mes outils / Mon quotidien',
        role: 'Les aides pratiques du quotidien de l’enseignant.',
        etapes: [
          'Calculatrice : opérations, moyennes et barèmes.',
          'Horloge : alarme pour marquer la fin d’une séance.',
          'Boîte à outils : groupes de travail et appréciations.',
        ],
        sorties: 'PDF · Impression',
      },
    ],
  },
  {
    id: 'ch11',
    titre: '11. Vie de l’établissement',
    resume: 'Administration, courriers, calendrier et enrôlement.',
    fiches: [
      {
        titre: 'Administration scolaire',
        chemin: 'Accueil → Administration scolaire',
        role: 'Piloter l’établissement et rédiger les documents officiels.',
        etapes: [
          'Onglet Pilotage : effectifs, moyenne de l’école, taux de réussite.',
          'Onglet Documents : rédigez dans le traitement de texte intégré (gras, titres, tableaux).',
          'Exportez en Word, en PDF, ou imprimez.',
          'Onglets Checklists et Priorités : préparez l’inspection et suivez vos tâches.',
        ],
        sorties: 'Word · PDF · Impression',
        astuce: 'Le Word exporté reste modifiable, contrairement au PDF qui est figé. Vous pouvez aussi importer un document Word existant.',
      },
      {
        titre: 'Calendrier, correspondance et grands rendez-vous',
        chemin: 'Accueil → Mon quotidien / Correspondance',
        role: 'Suivre les dates importantes et rédiger les courriers de l’école.',
        etapes: [
          'Calendrier scolaire : enregistrez les événements de l’année.',
          'Correspondance : l’en-tête reprend automatiquement votre profil.',
          'Grands rendez-vous : préparez les grands événements.',
        ],
        sorties: 'PDF · Impression',
      },
      {
        titre: 'Enrôlement des élèves et du personnel',
        chemin: 'Accueil → Enrôlement',
        role: 'Constituer les fiches d’enrôlement officielles.',
        etapes: [
          'Enrôlement des élèves : fiches et liste Excel.',
          'Enrôlement du personnel : matricule, Id ANPE, IFU.',
          'Exportez au format Excel officiel.',
        ],
        sorties: 'Excel · PDF · Impression',
        astuce: 'Ces deux fonctions sont incluses dès la formule Essentiel (999 FCFA/an).',
      },
    ],
  },
  {
    id: 'ch12',
    titre: '12. L’espace des parents',
    resume: 'Remettre à chaque parent le dossier chiffré de son enfant.',
    fiches: [
      {
        titre: 'Dossier pour les parents (enseignant)',
        chemin: 'Accueil → Suivi de votre enfant → Dossier pour les parents',
        role: 'Remettre un dossier chiffré contenant les résultats d’UN seul enfant.',
        etapes: [
          'Choisissez la classe puis l’élève.',
          'Ajoutez si vous le souhaitez un mot pour le parent.',
          'Touchez « Générer le code » : il s’affiche UNE SEULE FOIS, notez-le.',
          'Touchez « Créer le dossier » : le fichier chiffré est téléchargé.',
          'Remettez le fichier au parent, et le code SÉPARÉMENT en main propre.',
        ],
        sorties: 'Fichier chiffré (.msp)',
        attention: 'Le code et le fichier ne doivent jamais voyager ensemble. Sans le code, le fichier est illisible. Le code est valable 30 jours et peut être révoqué.',
      },
      {
        titre: 'Mon espace parent',
        chemin: 'Écran d’accueil → Suivi de votre enfant',
        role: 'Permettre au parent de consulter les résultats de son enfant.',
        etapes: [
          'Le parent donne son accord : rien n’est enregistré avant.',
          'Il choisit le fichier reçu et saisit le code de l’enseignant.',
          'Il consulte notes, progression, absences et mot de l’enseignant.',
          'Il peut retirer son accord : toutes les données sont alors effacées.',
        ],
        sorties: 'PDF · Impression',
        astuce: 'L’espace parent est GRATUIT : un parent n’est pas un abonné et n’a besoin d’aucun code d’abonnement.',
      },
    ],
  },
  {
    id: 'ch13',
    titre: '13. Le guide de l’utilisateur',
    resume: 'Ce manuel, et les tutoriels vidéo de l’équipe.',
    fiches: [
      {
        titre: 'Le manuel de l’abonné',
        chemin: 'Accueil → Guide → Le manuel de l’abonné',
        role: 'Consulter, dans l’application, le mode d’emploi de chaque fonction.',
        etapes: [
          'Dépliez un chapitre pour voir ses fiches.',
          'Utilisez la recherche pour trouver une fonction précise.',
          'Exportez le manuel en PDF ou imprimez-le.',
        ],
        sorties: 'PDF · Impression',
        astuce: 'Le manuel fonctionne SANS CONNEXION : consultez-le en classe, même sans réseau.',
      },
      {
        titre: 'Tutoriels Master Soutien Pédagogique',
        chemin: 'Accueil → Guide → Tutoriels',
        role: 'Regarder les vidéos d’utilisation publiées par l’équipe.',
        etapes: [
          'Les vidéos sont classées par rubrique, selon les chapitres de ce manuel.',
          'Touchez une vidéo : elle se lit directement dans l’application.',
          'Utilisez la recherche pour trouver un tutoriel précis.',
        ],
        sorties: 'Lecture vidéo dans l’application',
        attention: 'Les tutoriels sont des vidéos en ligne : une connexion internet est nécessaire. Le manuel, lui, fonctionne hors connexion.',
        astuce: 'Si aucun tutoriel n’apparaît, l’équipe n’en a pas encore publié. Consultez le manuel en attendant.',
      },
      {
        titre: 'Publier un tutoriel (administration)',
        chemin: 'Espace d’administration → Guide → Tutoriels',
        role: 'Réservé à l’équipe : mettre des vidéos à disposition des abonnés.',
        etapes: [
          'Touchez « Ajouter un tutoriel ».',
          'Collez le lien YouTube : tous les formats sont acceptés.',
          'Renseignez titre, rubrique et durée, puis cochez « Publié ».',
        ],
        sorties: '—',
        attention: 'Réglez vos vidéos en « Non répertoriée » sur YouTube : elles seront introuvables par une recherche publique. L’application empêche d’en sortir, mais ne peut pas rendre une vidéo secrète.',
      },
    ],
  },
  {
    id: 'ch14',
    titre: '14. Administration (Super Administrateur)',
    resume: 'Codes d’accès, équipe et contenus de l’application.',
    fiches: [
      {
        titre: 'Espace d’administration',
        chemin: 'Écran d’accès → bouton Administration',
        role: 'Gérer les codes, l’équipe et les contenus de l’application.',
        etapes: [
          'Générer des codes : choisissez la formule, saisissez le nom, générez.',
          'Nommer les membres de l’équipe et définir leur responsabilité.',
          'Modifier toute information, y compris les Conditions d’utilisation.',
          'Paramétrer les coordonnées de paiement et publier les tutoriels.',
        ],
        sorties: 'Codes · Excel · PDF',
        attention: 'Seuls les Super Administrateurs génèrent des codes. Les codes délivrés ne sont JAMAIS effacés par une mise à jour.',
      },
    ],
  },
];

/** Nombre total de fiches du manuel intégré. */
export function totalFiches(): number {
  return MANUAL.reduce((t, c) => t + c.fiches.length, 0);
}

/**
 * Recherche plein texte dans tout le manuel.
 *
 * ⚠️ INSENSIBLE AUX ACCENTS (corrigé v58). Sur un téléphone, un enseignant
 * tape rarement les accents : chercher « remediation » ou « enrolement »
 * doit trouver « remédiation » et « enrôlement ». Une recherche littérale
 * ne renvoyait rien et laissait croire que la fonction n'existait pas.
 */
export function searchManual(query: string): { chapitre: string; fiche: ManualStep }[] {
  const q = normalizeSearch(query);
  if (!q) return [];
  const out: { chapitre: string; fiche: ManualStep }[] = [];
  for (const c of MANUAL) {
    for (const f of c.fiches) {
      const blob = `${f.titre} ${f.chemin} ${f.role} ${f.etapes.join(' ')} `
        + `${f.astuce || ''} ${f.attention || ''}`;
      if (normalizeSearch(blob).includes(q)) out.push({ chapitre: c.titre, fiche: f });
    }
  }
  return out;
}
