import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSmartBack } from '../utils/useSmartBack';
import {
  ChevronLeft, FileUp, Trash2, Eye, EyeOff, Plus, Loader2, FileText, Layers, ShieldCheck,
} from 'lucide-react';
import {
  PrepFiche, PrepFichePage, generateFicheId, extractPages, savePrepFiche,
  getAllPrepFiches, deletePrepFiche, setFichePublished, groupByClasse,
  personalizationPrice, PRICE_PER_PAGE,
} from '../utils/prepFiches';
import { ADMIN_PASSWORD } from '../utils/adminConfig';
import { getAdminSession } from '../utils/adminSession';

const CLASSES_SUGGESTIONS = [
  'CI', 'CP', 'CE1', 'CE2', 'CM1', 'CM2',
  '6ème', '5ème', '4ème', '3ème', '2nde', '1ère', 'Tle',
];

export default function AdminPrepFichesScreen() {
  const navigate = useNavigate();
  const goBack = useSmartBack();

  // Accès réservé à l'équipe d'administration.
  const [authorized, setAuthorized] = useState<boolean>(() => !!getAdminSession());
  const [pwd, setPwd] = useState('');
  const [pwdError, setPwdError] = useState('');

  const [fiches, setFiches] = useState<PrepFiche[]>([]);
  const [loading, setLoading] = useState(true);

  // Formulaire d'ajout
  const [classe, setClasse] = useState('');
  const [matiere, setMatiere] = useState('');
  const [titre, setTitre] = useState('');
  const [description, setDescription] = useState('');
  const [pages, setPages] = useState<PrepFichePage[]>([]);
  const [processing, setProcessing] = useState(false);
  const [progress, setProgress] = useState('');
  const [saving, setSaving] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (authorized) refresh();
  }, [authorized]);

  async function refresh() {
    setLoading(true);
    try {
      setFiches(await getAllPrepFiches());
    } finally {
      setLoading(false);
    }
  }

  const grouped = useMemo(() => groupByClasse(fiches), [fiches]);

  function tryPassword() {
    if (pwd.trim() === ADMIN_PASSWORD) {
      setAuthorized(true);
      setPwdError('');
    } else {
      setPwdError('Mot de passe administrateur incorrect.');
    }
  }

  async function handleFiles(files: FileList | null) {
    if (!files || files.length === 0) return;
    setProcessing(true);
    setProgress('Préparation…');
    try {
      const extracted = await extractPages(Array.from(files), (label) => setProgress(label));
      setPages((prev) => [...prev, ...extracted]);
      setProgress('');
    } catch (e: any) {
      alert(e?.message || "Impossible de lire ces fichiers.");
    } finally {
      setProcessing(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  }

  function removePage(index: number) {
    setPages((prev) => prev.filter((_, i) => i !== index));
  }

  function resetForm() {
    setClasse('');
    setMatiere('');
    setTitre('');
    setDescription('');
    setPages([]);
    setProgress('');
  }

  async function submit(publish: boolean) {
    if (!classe.trim()) return alert('Indiquez la classe (ex : CE1, 6ème…).');
    if (!matiere.trim()) return alert('Indiquez la matière ou la discipline.');
    if (!titre.trim()) return alert('Donnez un titre à la fiche.');
    if (pages.length === 0) return alert('Ajoutez au moins une page (image ou PDF).');

    setSaving(true);
    try {
      const fiche: PrepFiche = {
        id: generateFicheId(),
        classe: classe.trim(),
        matiere: matiere.trim(),
        titre: titre.trim(),
        description: description.trim(),
        pages,
        pageCount: pages.length,
        published: publish,
        createdAt: Date.now(),
      };
      await savePrepFiche(fiche);
      await refresh();
      resetForm();
      alert(
        publish
          ? `Fiche mise en ligne ✔\nElle porte le filigrane « Master Soutien Pédagogique ».\nPersonnalisation pour l'utilisateur : ${personalizationPrice(fiche)} F (${pages.length} page(s) × ${PRICE_PER_PAGE} F).`
          : 'Fiche enregistrée en brouillon (non visible par les utilisateurs).',
      );
    } finally {
      setSaving(false);
    }
  }

  async function togglePublish(f: PrepFiche) {
    await setFichePublished(f.id, !f.published);
    await refresh();
  }

  async function remove(f: PrepFiche) {
    if (!confirm(`Supprimer définitivement la fiche « ${f.titre} » (${f.classe} — ${f.matiere}) ?`)) return;
    await deletePrepFiche(f.id);
    await refresh();
  }

  if (!authorized) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-lg p-6 w-full max-w-sm">
          <div className="flex items-center gap-2 mb-2 text-slate-800">
            <ShieldCheck className="w-6 h-6 text-emerald-600" />
            <h1 className="font-bold text-lg">Espace administration</h1>
          </div>
          <p className="text-sm text-gray-500 mb-4">
            Gestion des fiches de préparation « Master Soutien Pédagogique ». Réservé à l'équipe d'administration.
          </p>
          <label className="block text-sm font-medium text-gray-700 mb-1">Mot de passe administrateur</label>
          <input
            type="password"
            value={pwd}
            onChange={(e) => setPwd(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && tryPassword()}
            className="w-full p-3 border border-gray-300 rounded-lg mb-2"
            placeholder="Mot de passe"
          />
          {pwdError && <p className="text-red-600 text-sm mb-2">{pwdError}</p>}
          <button onClick={tryPassword} className="w-full bg-emerald-600 text-white py-3 rounded-xl font-semibold">Entrer</button>
          <button onClick={() => navigate('/')} className="w-full text-gray-500 text-sm mt-3">Retour à l'accueil</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-slate-900 text-white p-4 sticky top-0 z-10 shadow">
        <div className="flex items-center gap-3">
          <button onClick={() => goBack()} className="p-2 bg-white/10 rounded-lg"><ChevronLeft className="w-6 h-6" /></button>
          <div className="flex-1">
            <h1 className="font-bold text-lg">Fiches de préparation par classe</h1>
            <p className="text-slate-300 text-sm">Mise en ligne avec filigrane « Master Soutien Pédagogique »</p>
          </div>
        </div>
      </header>

      <main className="p-4 pb-24 max-w-4xl mx-auto space-y-5">
        {/* Ajout */}
        <section className="bg-white rounded-2xl shadow p-4">
          <h2 className="font-bold text-gray-900 text-lg mb-1 flex items-center gap-2">
            <Plus className="w-5 h-5 text-emerald-600" /> Nouvelle fiche de préparation
          </h2>
          <p className="text-gray-500 text-sm mb-4">
            Classez la fiche par <strong>classe</strong> et par <strong>matière / discipline</strong>, puis ajoutez ses
            pages (images ou PDF). À la mise en ligne, la fiche porte automatiquement le filigrane
            <strong> « Master Soutien Pédagogique »</strong>. La personnalisation du filigrane coûtera à l'utilisateur
            <strong> {PRICE_PER_PAGE} F par page</strong>.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Classe</label>
              <input
                list="classes-list"
                value={classe}
                onChange={(e) => setClasse(e.target.value)}
                placeholder="Ex : CE1, CM2, 6ème…"
                className="w-full p-3 border border-gray-300 rounded-lg"
              />
              <datalist id="classes-list">
                {CLASSES_SUGGESTIONS.map((c) => <option key={c} value={c} />)}
              </datalist>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Matière / Discipline</label>
              <input
                value={matiere}
                onChange={(e) => setMatiere(e.target.value)}
                placeholder="Ex : Mathématiques, Français, SVT…"
                className="w-full p-3 border border-gray-300 rounded-lg"
              />
            </div>
          </div>

          <div className="mt-3">
            <label className="block text-sm font-medium text-gray-700 mb-1">Titre de la fiche</label>
            <input
              value={titre}
              onChange={(e) => setTitre(e.target.value)}
              placeholder="Ex : Addition avec retenue — Séquence 3"
              className="w-full p-3 border border-gray-300 rounded-lg"
            />
          </div>

          <div className="mt-3">
            <label className="block text-sm font-medium text-gray-700 mb-1">Description (facultatif)</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={2}
              className="w-full p-3 border border-gray-300 rounded-lg resize-none"
              placeholder="Compétence visée, période, remarques…"
            />
          </div>

          {/* Pages */}
          <div className="mt-4">
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-medium text-gray-700">Pages de la fiche</label>
              <span className="text-xs text-gray-500">{pages.length} page(s)</span>
            </div>

            <input
              ref={fileRef}
              type="file"
              accept="image/*,application/pdf,.pdf"
              multiple
              className="hidden"
              onChange={(e) => handleFiles(e.target.files)}
            />
            <button
              onClick={() => fileRef.current?.click()}
              disabled={processing}
              className="w-full border-2 border-dashed border-emerald-300 rounded-xl py-6 flex flex-col items-center justify-center gap-2 text-emerald-700 disabled:opacity-60"
            >
              {processing ? <Loader2 className="w-6 h-6 animate-spin" /> : <FileUp className="w-6 h-6" />}
              <span className="text-sm font-semibold">
                {processing ? (progress || 'Traitement…') : 'Ajouter des pages (images ou PDF)'}
              </span>
              <span className="text-xs text-gray-500">Un PDF est automatiquement découpé en pages</span>
            </button>

            {pages.length > 0 && (
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 mt-3">
                {pages.map((p, i) => (
                  <div key={i} className="relative group">
                    <img src={p.dataUrl} alt={`Page ${i + 1}`} className="w-full h-28 object-cover rounded-lg border" />
                    <span className="absolute bottom-1 left-1 bg-black/60 text-white text-[10px] px-1.5 py-0.5 rounded">
                      Page {i + 1}
                    </span>
                    <button
                      onClick={() => removePage(i)}
                      className="absolute top-1 right-1 bg-red-600 text-white rounded-full p-1"
                      title="Retirer cette page"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {pages.length > 0 && (
              <p className="text-xs text-emerald-700 bg-emerald-50 rounded-lg p-2 mt-3">
                Personnalisation du filigrane pour l'utilisateur :
                <strong> {pages.length * PRICE_PER_PAGE} F</strong> ({pages.length} × {PRICE_PER_PAGE} F).
              </p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-2 mt-4">
            <button
              onClick={() => submit(false)}
              disabled={saving || processing}
              className="bg-gray-100 text-gray-700 py-3 rounded-xl font-semibold disabled:opacity-60"
            >
              Enregistrer (brouillon)
            </button>
            <button
              onClick={() => submit(true)}
              disabled={saving || processing}
              className="bg-emerald-600 text-white py-3 rounded-xl font-semibold disabled:opacity-60 inline-flex items-center justify-center gap-2"
            >
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Eye className="w-4 h-4" />} Mettre en ligne
            </button>
          </div>
        </section>

        {/* Liste */}
        <section>
          <h2 className="font-bold text-gray-900 text-lg mb-3 flex items-center gap-2">
            <Layers className="w-5 h-5 text-slate-700" /> Fiches enregistrées
          </h2>

          {loading ? (
            <div className="text-center py-8 text-gray-500"><Loader2 className="w-6 h-6 animate-spin inline" /></div>
          ) : fiches.length === 0 ? (
            <div className="bg-white rounded-xl border border-dashed border-gray-300 p-6 text-center text-gray-500 text-sm">
              Aucune fiche pour l'instant.
            </div>
          ) : (
            <div className="space-y-4">
              {grouped.map((g) => (
                <div key={g.classe} className="bg-white rounded-2xl shadow p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-bold text-emerald-700">{g.classe}</h3>
                    <span className="text-xs text-gray-500">{g.total} fiche(s)</span>
                  </div>
                  {g.matieres.map((m) => (
                    <div key={m.matiere} className="mb-3 last:mb-0">
                      <p className="text-sm font-semibold text-gray-600 mb-2">{m.matiere}</p>
                      <div className="space-y-2">
                        {m.fiches.map((f) => (
                          <div key={f.id} className="border rounded-xl p-3 flex items-center gap-3">
                            <img src={f.pages[0]?.dataUrl} alt="" className="w-12 h-16 object-cover rounded border shrink-0" />
                            <div className="flex-1 min-w-0">
                              <p className="font-semibold text-gray-800 truncate">{f.titre}</p>
                              <p className="text-xs text-gray-500 flex items-center gap-1">
                                <FileText className="w-3 h-3" /> {f.pageCount} page(s) • perso. {personalizationPrice(f)} F
                              </p>
                              <span className={`inline-block mt-1 text-[11px] px-2 py-0.5 rounded ${f.published ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
                                {f.published ? 'En ligne' : 'Brouillon'}
                              </span>
                            </div>
                            <div className="flex flex-col gap-1 shrink-0">
                              <button
                                onClick={() => togglePublish(f)}
                                className={`text-xs px-2 py-1 rounded font-medium inline-flex items-center gap-1 ${f.published ? 'bg-amber-50 text-amber-700' : 'bg-emerald-50 text-emerald-700'}`}
                              >
                                {f.published ? <><EyeOff className="w-3 h-3" /> Retirer</> : <><Eye className="w-3 h-3" /> Publier</>}
                              </button>
                              <button onClick={() => remove(f)} className="text-xs px-2 py-1 rounded font-medium bg-red-50 text-red-600 inline-flex items-center gap-1">
                                <Trash2 className="w-3 h-3" /> Suppr.
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          )}
        </section>
      </main>
    </div>
  );
}
