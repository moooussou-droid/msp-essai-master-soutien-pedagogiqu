/**
 * Assistant pédagogique conversationnel (v37) — 100 % hors-ligne.
 *
 * L'assistant pose ses questions une par une, réagit à chaque réponse,
 * adapte la suite de l'entretien, récapitule, puis rédige le document.
 * Aucune clé API, aucune connexion internet nécessaire.
 */

import { useEffect, useRef, useState } from 'react';
import { useSmartBack } from '../utils/useSmartBack';
import { Bot, ChevronLeft, Printer, RefreshCw, Save, Send, SkipForward, User, Wand2, FileText, Pencil } from 'lucide-react';
import {
  acknowledge,
  answersToPromptInput,
  interviewProgress,
  interviewRecap,
  nextQuestion,
  type InterviewAnswers,
  type InterviewQuestion,
} from '../utils/aiInterview';
import { enrichLesson } from '../utils/lessonEnrichment';
import { generateLocalLesson } from '../utils/localPedagogicalEngine';
import type { GeneratedLessonPlan } from '../utils/aiLessonGenerator';
import { downloadFicheDocx, printFiche } from '../utils/ficheExport';

const FICHES_KEY = 'msp_fiches_pedagogiques';

interface Msg {
  role: 'bot' | 'user';
  text: string;
  hint?: string;
}

function saveGeneratedAsFiche(plan: GeneratedLessonPlan) {
  let fiches: any[] = [];
  try {
    fiches = JSON.parse(localStorage.getItem(FICHES_KEY) || '[]');
  } catch {
    fiches = [];
  }
  const fiche = {
    id: `fiche-ia-chat-${Date.now()}`,
    titre: plan.titre,
    classe: plan.classe,
    matiere: plan.matiere,
    domaine: plan.domaine,
    duree: plan.duree,
    date: new Date().toISOString().split('T')[0],
    competence: plan.competence,
    objectif: plan.objectif,
    materiel: plan.materiel,
    deroulement: plan.deroulement,
    evaluation: plan.evaluation,
    statut: 'prete',
    createdAt: Date.now(),
  };
  localStorage.setItem(FICHES_KEY, JSON.stringify([fiche, ...fiches]));
}

export default function AIAssistantChatScreen() {
  const goBack = useSmartBack();
  const [answers, setAnswers] = useState<InterviewAnswers>({});
  const [messages, setMessages] = useState<Msg[]>([]);
  const [current, setCurrent] = useState<InterviewQuestion | null>(null);
  const [input, setInput] = useState('');
  const [thinking, setThinking] = useState(false);
  const [plan, setPlan] = useState<GeneratedLessonPlan | null>(null);
  const [editing, setEditing] = useState(false);
  const [saved, setSaved] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  // Première question au montage
  useEffect(() => {
    const q = nextQuestion({});
    if (q) {
      setCurrent(q);
      setMessages([{ role: 'bot', text: q.text, hint: q.hint }]);
    }
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, thinking, plan]);

  const progress = interviewProgress(answers);
  const pct = progress.total ? Math.round((progress.done / progress.total) * 100) : 0;

  function pushBot(text: string, hint?: string) {
    setMessages((m) => [...m, { role: 'bot', text, hint }]);
  }

  function submit(value: string) {
    if (!current) return;
    const clean = value.trim();
    if (!clean && !current.optional) return;

    const nextAnswers: InterviewAnswers = { ...answers, [current.id]: clean };
    setAnswers(nextAnswers);
    setInput('');
    setMessages((m) => [...m, { role: 'user', text: clean || '(passer)' }]);
    setCurrent(null);
    setThinking(true);

    // Petite latence pour l'effet conversationnel
    window.setTimeout(() => {
      setThinking(false);
      pushBot(acknowledge(current.id, clean, nextAnswers));
      const q = nextQuestion(nextAnswers);
      if (q) {
        setCurrent(q);
        window.setTimeout(() => pushBot(q.text, q.hint), 250);
      } else {
        window.setTimeout(() => {
          pushBot('J’ai tout ce qu’il me faut. Voici le récapitulatif de votre demande — vérifiez, puis lancez la rédaction.');
        }, 250);
      }
    }, 420);
  }

  function generate() {
    setThinking(true);
    window.setTimeout(() => {
      const base = generateLocalLesson(answersToPromptInput(answers));
      setPlan(enrichLesson(base, answers));
      setThinking(false);
      setSaved(false);
      pushBot('Votre document est prêt. Vous pouvez le modifier librement, l’enregistrer dans « Mes fiches », l’imprimer ou le télécharger en Word.');
    }, 700);
  }

  function restart() {
    setAnswers({});
    setPlan(null);
    setEditing(false);
    setSaved(false);
    const q = nextQuestion({});
    setCurrent(q);
    setMessages(q ? [{ role: 'bot', text: q.text, hint: q.hint }] : []);
  }

  /** Revenir sur une réponse déjà donnée. */
  function reopen(id: string) {
    const copy = { ...answers };
    delete copy[id];
    setAnswers(copy);
    setPlan(null);
    const q = nextQuestion(copy);
    setCurrent(q);
    if (q) pushBot(q.text, q.hint);
  }

  const recap = interviewRecap(answers);
  const done = !current && !thinking;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <header className="bg-emerald-600 text-white p-4 sticky top-0 z-10 shadow">
        <div className="flex items-center gap-3">
          <button onClick={goBack} className="p-2 bg-white/20 rounded-lg" aria-label="Retour">
            <ChevronLeft className="w-6 h-6" />
          </button>
          <div className="flex-1">
            <h1 className="font-bold text-lg">Assistant pédagogique IA</h1>
            <p className="text-emerald-100 text-xs">Conversation guidée · fonctionne sans internet ni clé</p>
          </div>
          <button onClick={restart} className="p-2 bg-white/20 rounded-lg" aria-label="Recommencer">
            <RefreshCw className="w-5 h-5" />
          </button>
        </div>
        <div className="mt-3 h-2 bg-white/25 rounded-full overflow-hidden">
          <div className="h-full bg-white rounded-full transition-all" style={{ width: `${pct}%` }} />
        </div>
        <p className="text-emerald-100 text-[11px] mt-1">{progress.done} question(s) sur {progress.total} · {pct} %</p>
      </header>

      <main className="flex-1 p-4 space-y-3 pb-40">
        {messages.map((m, i) => (
          <div key={i} className={`flex gap-2 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            {m.role === 'bot' && (
              <div className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0">
                <Bot className="w-5 h-5" />
              </div>
            )}
            <div
              className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm shadow-sm whitespace-pre-wrap ${
                m.role === 'user' ? 'bg-emerald-600 text-white rounded-br-sm' : 'bg-white text-gray-800 rounded-bl-sm border border-gray-100'
              }`}
            >
              {m.text}
              {m.hint && <p className="mt-2 text-xs text-gray-500 italic">{m.hint}</p>}
            </div>
            {m.role === 'user' && (
              <div className="w-8 h-8 rounded-full bg-gray-300 text-gray-700 flex items-center justify-center shrink-0">
                <User className="w-5 h-5" />
              </div>
            )}
          </div>
        ))}

        {thinking && (
          <div className="flex gap-2">
            <div className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0">
              <Bot className="w-5 h-5" />
            </div>
            <div className="bg-white border border-gray-100 rounded-2xl rounded-bl-sm px-4 py-3 shadow-sm flex gap-1 items-center">
              <span className="w-2 h-2 bg-emerald-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
              <span className="w-2 h-2 bg-emerald-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
              <span className="w-2 h-2 bg-emerald-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
            </div>
          </div>
        )}

        {/* Récapitulatif + bouton de génération */}
        {done && !plan && recap.length > 0 && (
          <div className="bg-white rounded-2xl border border-emerald-200 shadow p-4">
            <h2 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
              <FileText className="w-5 h-5 text-emerald-600" /> Récapitulatif de votre demande
            </h2>
            <div className="space-y-1.5">
              {recap.map((r) => (
                <div key={r.label} className="flex items-start justify-between gap-3 text-sm border-b border-gray-100 pb-1.5">
                  <span className="text-gray-500 shrink-0">{r.label}</span>
                  <span className="text-gray-800 font-medium text-right flex-1">{r.value}</span>
                  <button onClick={() => reopen(labelToId(r.label))} className="text-emerald-600 text-xs underline shrink-0">
                    modifier
                  </button>
                </div>
              ))}
            </div>
            <button
              onClick={generate}
              className="w-full mt-4 bg-emerald-600 text-white py-3 rounded-xl font-bold flex items-center justify-center gap-2"
            >
              <Wand2 className="w-5 h-5" /> Rédiger mon document
            </button>
          </div>
        )}

        {/* Résultat */}
        {plan && (
          <div className="bg-white rounded-2xl border border-emerald-200 shadow p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="font-bold text-gray-800">{plan.titre}</h2>
              <button
                onClick={() => setEditing(!editing)}
                className="text-emerald-700 text-sm flex items-center gap-1 bg-emerald-50 px-3 py-1.5 rounded-lg"
              >
                <Pencil className="w-4 h-4" /> {editing ? 'Aperçu' : 'Modifier'}
              </button>
            </div>

            {(['classe', 'matiere', 'duree', 'competence', 'objectif', 'materiel', 'deroulement', 'evaluation'] as const).map((k) => (
              <div key={k}>
                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">{FIELD_LABELS[k]}</label>
                {editing ? (
                  <textarea
                    value={plan[k]}
                    onChange={(e) => setPlan({ ...plan, [k]: e.target.value })}
                    rows={k === 'deroulement' || k === 'evaluation' ? 12 : 2}
                    className="w-full p-3 border border-gray-300 rounded-lg text-sm"
                  />
                ) : (
                  <p className="text-sm text-gray-800 whitespace-pre-wrap bg-gray-50 rounded-lg p-3">{plan[k]}</p>
                )}
              </div>
            ))}

            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                onClick={() => {
                  saveGeneratedAsFiche(plan);
                  setSaved(true);
                }}
                className="bg-emerald-600 text-white py-3 rounded-xl font-semibold flex items-center justify-center gap-2"
              >
                <Save className="w-5 h-5" /> {saved ? 'Enregistrée ✓' : 'Mes fiches'}
              </button>
              <button onClick={() => printFiche(plan)} className="bg-[#006b4f] text-white py-3 rounded-xl font-semibold flex items-center justify-center gap-2">
                <Printer className="w-5 h-5" /> Imprimer
              </button>
            </div>
            <button
              onClick={() => downloadFicheDocx(plan)}
              className="w-full bg-white border border-emerald-300 text-emerald-700 py-3 rounded-xl font-semibold flex items-center justify-center gap-2"
            >
              <FileText className="w-5 h-5" /> Télécharger en Word
            </button>
            <button onClick={restart} className="w-full text-gray-500 text-sm underline pt-1">
              Préparer un autre document
            </button>
          </div>
        )}

        <div ref={bottomRef} />
      </main>

      {/* Zone de saisie */}
      {current && (
        <div className="sticky bottom-0 bg-white border-t border-gray-200 p-3 space-y-2">
          {current.chips.length > 0 && (
            <div className="flex gap-2 overflow-x-auto pb-1">
              {current.chips.map((c) => (
                <button
                  key={c}
                  onClick={() => submit(c)}
                  className="shrink-0 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-full px-3 py-2 text-sm font-medium"
                >
                  {c}
                </button>
              ))}
            </div>
          )}
          <div className="flex gap-2">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') submit(input);
              }}
              placeholder="Écrivez votre réponse..."
              className="flex-1 p-3 border border-gray-300 rounded-xl text-sm"
            />
            {current.optional && (
              <button onClick={() => submit('')} className="px-3 bg-gray-100 text-gray-600 rounded-xl" aria-label="Passer">
                <SkipForward className="w-5 h-5" />
              </button>
            )}
            <button
              onClick={() => submit(input)}
              disabled={!input.trim() && !current.optional}
              className="px-4 bg-emerald-600 text-white rounded-xl disabled:opacity-40"
              aria-label="Envoyer"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

const FIELD_LABELS: Record<string, string> = {
  classe: 'Classe',
  matiere: 'Matière',
  duree: 'Durée',
  competence: 'Compétence visée',
  objectif: 'Objectif',
  materiel: 'Matériel',
  deroulement: 'Déroulement',
  evaluation: 'Évaluation et remédiation',
};

function labelToId(label: string): string {
  const map: Record<string, string> = {
    Production: 'kind',
    Classe: 'niveau',
    'Matière': 'matiere',
    'Thème': 'theme',
    'Durée': 'duree',
    Effectif: 'effectif',
    'Matériel': 'materiel',
    'Prérequis': 'prerequis',
    'Difficulté visée': 'obstacle',
    'Ancrage local': 'contexte',
    'Appui principal': 'oral',
    Manipulation: 'experience',
    'Support de langue': 'support_texte',
    'Volume d’exercices': 'volume_exercices',
    Diffusion: 'support_numerique',
    'Évaluation': 'evaluation',
    'Différenciation': 'differenciation',
    Norme: 'standard',
    'Exigence particulière': 'consignes',
  };
  return map[label] || label;
}
