# Déployer « Master Soutien Pédagogique » sur Vercel

L'application est prête pour Vercel. La configuration se trouve déjà dans
`vercel.json` à la racine du projet :

| Réglage | Valeur | Rôle |
|---|---|---|
| **Build Command** | `npm run build:lowmem` | Compile l'app avec esbuild (rapide, faible mémoire, ~1,5 s) |
| **Output Directory** | `dist` | Dossier publié (index.html + assets + fichiers PWA) |
| **Framework Preset** | `Other` (`framework: null`) | On utilise notre propre build |
| **Rewrites** | `/(.*) → /index.html` | Indispensable pour le routage React (SPA) |
| **Headers** | `sw.js`, `manifest.json`, `index.html` en `no-cache` | Le service worker et le manifeste PWA restent à jour |

> Pourquoi `build:lowmem` (esbuild) plutôt que `npm run build` (Vite) ?
> Les deux produisent le même résultat déployable. Le build esbuild est
> beaucoup plus rapide et ne sature jamais la mémoire — il fonctionne quelle
> que soit la RAM de la machine de build.

---

## Méthode 1 — via Git (recommandée)

C'est la méthode idéale : chaque `git push` redéploie automatiquement.

1. **Poussez le projet sur GitHub / GitLab / Bitbucket** (s'il ne l'est pas déjà) :
   ```bash
   cd msp-app
   git init
   git add .
   git commit -m "MSP app – plateforme MOOC + certificats"
   git branch -M main
   git remote add origin https://github.com/VOTRE-COMPTE/msp-app.git
   git push -u origin main
   ```
2. Allez sur **https://vercel.com/new** et connectez-vous.
3. Cliquez **Import** sur votre dépôt `msp-app`.
4. Vercel lit automatiquement `vercel.json`. **Ne changez rien** :
   - Build Command, Output Directory et Rewrites sont déjà configurés.
5. Cliquez **Deploy**. Après ~1 minute, votre app est en ligne sur une URL
   `https://msp-app-xxxx.vercel.app`.

À chaque nouveau `git push` sur `main`, Vercel reconstruit et redéploie tout seul.

---

## Méthode 2 — via la CLI Vercel (sans Git)

Sur votre ordinateur (Node.js installé) :

```bash
# 1. Installer la CLI une seule fois
npm i -g vercel

# 2. Depuis le dossier du projet
cd msp-app
vercel            # déploiement de prévisualisation (répondez aux questions)
vercel --prod     # déploiement en production
```

La CLI détecte `vercel.json` et applique les mêmes réglages.

---

## Méthode 3 — glisser-déposer (le plus simple, sans compte Git)

1. Construisez l'application localement :
   ```bash
   cd msp-app
   npm install
   npm run build:lowmem
   ```
2. Un dossier **`deploy/`** (identique à `dist/`) est généré, prêt à publier.
3. Allez sur **https://vercel.com** → **Add New… → Project → Deploy** puis
   déposez le contenu du dossier `deploy/`.

> Note : en glisser-déposer, Vercel ne lit pas toujours les `rewrites` du
> `vercel.json`. Le dossier contient déjà un `404.html` et un `_redirects`
> de secours, mais **la méthode Git est préférable** pour un routage SPA parfait.

---

## Vérifications après déploiement

- [ ] La page d'accueil s'affiche.
- [ ] La navigation directe vers une URL profonde (ex. `/formations`) fonctionne
      (grâce aux *rewrites*).
- [ ] L'installation PWA est proposée (icône « installer »).
- [ ] Un certificat MOOC se télécharge bien en PDF avec le **nom et prénoms** saisis.

## Dépannage

- **Page blanche sur une route rafraîchie** → vérifiez que les *rewrites* de
  `vercel.json` sont bien pris en compte (méthode Git recommandée).
- **Ancienne version affichée** → l'app est une PWA : videz le cache ou
  désinscrivez le service worker (DevTools → Application → Service Workers →
  *Unregister*), puis rechargez. Les en-têtes `no-cache` évitent ce souci sur
  les nouveaux déploiements.
- **Échec du build** → assurez-vous que Vercel utilise Node 18+ (Settings →
  General → Node.js Version).
